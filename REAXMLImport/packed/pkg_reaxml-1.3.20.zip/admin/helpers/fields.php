<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

class ReaXmlImportHelpersFields {
	public static function addAssets($document){
		$document->addScript('/administrator/components/com_reaxmlimport/assets/js/fields.js');
		$document->addScript('/administrator/components/com_reaxmlimport/assets/css/fields.css');
		
	}
}