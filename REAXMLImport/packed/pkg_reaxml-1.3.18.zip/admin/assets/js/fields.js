/**
 *
 * @package Component REAXML Import for Joomla! 3.4
 * @version 1.3.18: fields.js 2015-05-06T20:55:08.489
 * @author Clifton IT Foundries Pty Ltd
 * @link http://cliftonwebfoundry.com.au
 * @copyright Copyright (c) 2014, 2015 Clifton IT Foundries Pty Ltd. All rights Reserved
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 *
 **/
/**
 * Providing support for some custom form fields used by the REAXML Import component
 */
jQuery(document).ready(function(){
	//inject modal popup iframe div to receive dynamic component configuration form
	jQuery("body").append('<div id="reaxmlimport-config-panel"><iframe id="reaxmlimport-config-frame" src=""/></div>');
});