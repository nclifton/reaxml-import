/**
 *
 * @package Component REAXML Import for Joomla! 3.4
 * @version 1.3.22: fields.js 2015-05-08T23:37:16.781
 * @author Clifton IT Foundries Pty Ltd
 * @link http://cliftonwebfoundry.com.au
 * @copyright Copyright (c) 2014, 2015 Clifton IT Foundries Pty Ltd. All rights Reserved
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 *
 **/
/**
 * Providing support for some custom form fields used by the REAXML Import component
 */
jQuery(document).ready(function(){
	//inject modal popup iframe div to receive dynamic component configuration form
	jQuery("body").append('<div id="reaxmlimport-config-panel"><iframe id="reaxmlimport-config-frame" src=""/></div>');
	jQuery("#reaxmlimport-config-panel").dialog({
		autoOpen:false,
		position: "center",
		modal: true,
		height: "auto",
		width: "auto",
		close: function(){
			jQuery("#reaxmlimport-config-frame").attr("src","");
		}
	});
	function openFolderBrowser(inputId){

		jQuery("#reaxmlimport-config-panel").dialog("open");
		var value = jQuery("#"+inputId).attr("value");
		jQuery("#reaxmlimport-config-frame").attr("src","/administrator/index.php?option=com_reaxmlimport@controller=config&view=folderbrowser&inputid="+inputId+"&value="+value);
	}
});
